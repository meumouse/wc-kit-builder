jQuery(document).ready( function($) {
    $('.kit-item').click( function() {
        $('.kit-item').removeClass('active');
        $(this).addClass('active');
        
        var value = $(this).children('input.hidden').val();
        var kit_title = $(this).children('.kit-item-info').children('.kit-quantity').text();
        var attribute_name = $(this).data('attribute-name');

        $('select[name="' + attribute_name + '"]').val(value).change();
        $('h4.variation-title p').text(kit_title);
    });
});